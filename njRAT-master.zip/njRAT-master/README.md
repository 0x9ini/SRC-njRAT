# njRAT
njRAT SRC Extract
#### All responsibilities are at your own risk.
#### Please use it only for research purposes.
