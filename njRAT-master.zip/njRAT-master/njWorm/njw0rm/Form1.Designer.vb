﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.BuilderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MsgboxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScreenBlueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenWebPageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DosAttackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScriptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMDEXEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetPasswordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UninstallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Lv1 = New njw0rm.LV()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BuilderToolStripMenuItem, Me.MsgboxToolStripMenuItem, Me.ScreenBlueToolStripMenuItem, Me.OpenWebPageToolStripMenuItem, Me.DosAttackToolStripMenuItem, Me.RunFileToolStripMenuItem, Me.ScriptToolStripMenuItem, Me.CMDEXEToolStripMenuItem, Me.GetPasswordsToolStripMenuItem, Me.UpdateToolStripMenuItem, Me.UninstallToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(176, 268)
        '
        'BuilderToolStripMenuItem
        '
        Me.BuilderToolStripMenuItem.Image = CType(resources.GetObject("BuilderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BuilderToolStripMenuItem.Name = "BuilderToolStripMenuItem"
        Me.BuilderToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.BuilderToolStripMenuItem.Text = "Builder"
        '
        'MsgboxToolStripMenuItem
        '
        Me.MsgboxToolStripMenuItem.Image = CType(resources.GetObject("MsgboxToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MsgboxToolStripMenuItem.Name = "MsgboxToolStripMenuItem"
        Me.MsgboxToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.MsgboxToolStripMenuItem.Text = "Msgbox"
        '
        'ScreenBlueToolStripMenuItem
        '
        Me.ScreenBlueToolStripMenuItem.Image = CType(resources.GetObject("ScreenBlueToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ScreenBlueToolStripMenuItem.Name = "ScreenBlueToolStripMenuItem"
        Me.ScreenBlueToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.ScreenBlueToolStripMenuItem.Text = "Screen Blue"
        '
        'OpenWebPageToolStripMenuItem
        '
        Me.OpenWebPageToolStripMenuItem.Image = CType(resources.GetObject("OpenWebPageToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenWebPageToolStripMenuItem.Name = "OpenWebPageToolStripMenuItem"
        Me.OpenWebPageToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.OpenWebPageToolStripMenuItem.Text = "Open WebPage"
        '
        'DosAttackToolStripMenuItem
        '
        Me.DosAttackToolStripMenuItem.Image = CType(resources.GetObject("DosAttackToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DosAttackToolStripMenuItem.Name = "DosAttackToolStripMenuItem"
        Me.DosAttackToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.DosAttackToolStripMenuItem.Text = "Dos Attack"
        '
        'RunFileToolStripMenuItem
        '
        Me.RunFileToolStripMenuItem.Image = CType(resources.GetObject("RunFileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RunFileToolStripMenuItem.Name = "RunFileToolStripMenuItem"
        Me.RunFileToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.RunFileToolStripMenuItem.Text = "Download and Run"
        '
        'ScriptToolStripMenuItem
        '
        Me.ScriptToolStripMenuItem.Image = CType(resources.GetObject("ScriptToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ScriptToolStripMenuItem.Name = "ScriptToolStripMenuItem"
        Me.ScriptToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.ScriptToolStripMenuItem.Text = "Autoit Script"
        '
        'CMDEXEToolStripMenuItem
        '
        Me.CMDEXEToolStripMenuItem.Image = CType(resources.GetObject("CMDEXEToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CMDEXEToolStripMenuItem.Name = "CMDEXEToolStripMenuItem"
        Me.CMDEXEToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.CMDEXEToolStripMenuItem.Text = "CMD.EXE"
        '
        'GetPasswordsToolStripMenuItem
        '
        Me.GetPasswordsToolStripMenuItem.Image = CType(resources.GetObject("GetPasswordsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetPasswordsToolStripMenuItem.Name = "GetPasswordsToolStripMenuItem"
        Me.GetPasswordsToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.GetPasswordsToolStripMenuItem.Text = "Get Passwords"
        '
        'UpdateToolStripMenuItem
        '
        Me.UpdateToolStripMenuItem.Image = CType(resources.GetObject("UpdateToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem"
        Me.UpdateToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.UpdateToolStripMenuItem.Text = "Update"
        '
        'UninstallToolStripMenuItem
        '
        Me.UninstallToolStripMenuItem.Image = CType(resources.GetObject("UninstallToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UninstallToolStripMenuItem.Name = "UninstallToolStripMenuItem"
        Me.UninstallToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.UninstallToolStripMenuItem.Text = "Uninstall"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Image = CType(resources.GetObject("AboutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(175, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Timer1
        '
        '
        'Lv1
        '
        Me.Lv1.BackColor = System.Drawing.Color.Black
        Me.Lv1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Lv1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader6, Me.ColumnHeader5, Me.ColumnHeader7})
        Me.Lv1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Lv1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Lv1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.Lv1.ForeColor = System.Drawing.Color.White
        Me.Lv1.FullRowSelect = True
        Me.Lv1.Location = New System.Drawing.Point(0, 0)
        Me.Lv1.Name = "Lv1"
        Me.Lv1.Size = New System.Drawing.Size(552, 264)
        Me.Lv1.TabIndex = 0
        Me.Lv1.UseCompatibleStateImageBehavior = False
        Me.Lv1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Name"
        Me.ColumnHeader1.Width = 101
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "IP"
        Me.ColumnHeader2.Width = 88
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Country"
        Me.ColumnHeader3.Width = 62
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "OS"
        Me.ColumnHeader4.Width = 96
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Ver."
        Me.ColumnHeader6.Width = 40
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "USB"
        Me.ColumnHeader5.Width = 38
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Active Window"
        Me.ColumnHeader7.Width = 125
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(552, 264)
        Me.Controls.Add(Me.Lv1)
        Me.DoubleBuffered = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Nj-Worm v3.5"
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Lv1 As njw0rm.LV
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents RunFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UninstallToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ScriptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMDEXEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuilderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetPasswordsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenWebPageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DosAttackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MsgboxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScreenBlueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
