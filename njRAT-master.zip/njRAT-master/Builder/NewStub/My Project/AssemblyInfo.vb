﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Informações gerais sobre um assembly são controladas através do seguinte 
' conjunto de atributos. Altere o valor destes atributos para modificar a informação
' associada a um assembly.

' Revise os valores dos atributos do assembly

<Assembly: AssemblyTitle("NewStub")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("NewStub")> 
<Assembly: AssemblyCopyright("Copyright ©  2016")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'O GUID a seguir é para o ID da typelib se este projeto for exposto para COM
<Assembly: Guid("fc790ee5-163a-40f9-a1e2-9863c290ff8b")> 

' Informação de versão para um assembly consiste nos quatro valores a seguir:
'
'      Versão Principal
'      Versão Secundária 
'      Número da Versão
'      Revisão
'
' É possível especificar todos os valores ou usar o padrão de números da Compilação e de Revisão 
' utilizando o '*' como mostrado abaixo:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
